LAKIY ABAYA — Professional Website
===================================

Files:
- index.html — complete responsive website
- assets/lakiy-abaya-logo.jpeg — supplied logo

Features:
- Premium black/gold design based on the supplied logo
- About/services/business profile sections
- Responsive document upload interface
- Drag-and-drop document selection
- File type and size validation
- Customer name, email and message fields
- Social links and business contact details
- "Prepare Submission" opens an email draft addressed to mbelaluddin250@gmail.com

Important:
The upload interface is frontend-only. Browsers do not automatically send selected files through a normal mailto link.
For real document collection, connect the form to a secure backend, cloud storage, or a form provider and configure authentication/access controls before publishing.

Suggested deployment:
1. Upload index.html and the assets folder to your web host.
2. For real uploads, replace the mailto submission JavaScript with your secure upload API.
3. Use HTTPS and server-side file validation.
